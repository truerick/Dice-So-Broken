# Image license

Images are .svg files from Font Awesome transformed in png and  used without modification.

Font Awesome license is available at https://fontawesome.com/license/free.
